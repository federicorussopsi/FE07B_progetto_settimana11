import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  template: `


  <footer class=" bg-primary py-2  fixed-bottom">
    <div class="container">
      <p class="text-center text-white">  📱 Phone Shop 🛒 - Pochi telefoni, ma buoni</p>
    </div>
  </footer>
  `,
  styles: [ `
footer{
  font-size:0.8em;
}
span{
  font-size: 2em;
}
` ]
})
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
